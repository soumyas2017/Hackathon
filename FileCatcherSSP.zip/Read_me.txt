This application will work as like FTP streams in Eagle.Pickup the file from landing zone.

Things to DO:
=============

1. Please make sure you have Google Chrome to test this Application.
2. Please create a folder/directory in C: with name as LandingZone, so the url should look like C:\LandingZone
3. Once the abve steps are done, please create a sub-directory(Processed) inside the C:\LandingZone\Processed
3. Keep Ready with 2 files, source_file.xml and target_file.xml
4. Once the files said in #2 is dropped in the C:\LandingZone\ , you should see your Chrome opening and taking you to http://18.220.64.154:8080/Uploadv6/html/dashboard.html


